package teste;
import java.util.Scanner;
public class App {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        for (int i=0;i<3;i++){
        System.out.println("O que deseja fazer?");
        System.out.println("1 - Inclusão");
        System.out.println("2 - Exclusão");
        System.out.println("3 - Pesquisa");
        String escolha = teclado.nextLine();
        if (escolha == "1"){}
        else if (escolha == "1"){}
        else if (escolha == "1"){}
        else{System.out.println("Valor inválido!");}

        }
    }
}
