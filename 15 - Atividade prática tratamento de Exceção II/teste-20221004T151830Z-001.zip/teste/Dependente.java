package teste;
public class Dependente{
    String nome;
    String idade;
    String sexo;
    public Dependente(String nome, String idade, String sexo){
        this.nome = nome;
        this.idade = idade;
        this.sexo = sexo;
    }
}