package teste;
public class Professor{
    String nome;
    String idade;
    String sexo;
    String cpf;
    String rg;
    String endereco;
    Dependente dependente;

    static Professor vetor[] = new Professor[20];
    
    public Professor(String nome, String idade, String sexo, String rg, String endereco){
        this.nome = nome;
        this.idade = idade;
        this.sexo = sexo;
        this.cpf = cpf;
        this.rg = rg;
        this.endereco = endereco;
    }
    public Professor(String nome, String idade, String sexo, String rg, String endereco,Dependente dependente){
        this.nome = nome;
        this.idade = idade;
        this.sexo = sexo;
        this.cpf = cpf;
        this.rg = rg;
        this.endereco = endereco;
        this.dependente = dependente;
    }

}